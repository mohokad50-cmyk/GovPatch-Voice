"""
GovPatch Voice v1.2 — Judge Demo Runner
Executes Flow 1 (Legitimate), Flow 2 (Sovereign Block), and Flow 3 (Value Mismatch)
"""

from __future__ import annotations

import sys
import time
from gateway_core_v1_2_recovery_replica import (
    EvidenceError,
    GovernanceGateway,
    GovernanceState,
    SovereignDecisionField,
)

SECRET = b"DEMO_ONLY_LOCAL_HMAC_KEY_NOT_FOR_PRODUCTION"
APP_ID = "GOV-10482"


def print_step(title: str) -> None:
    print(f"\n{'='*70}\n>>> {title}\n{'='*70}")


def run_demo() -> int:
    print("\n" + "#" * 70)
    print("  GOVPATCH VOICE v1.2 — LIVE JUDICIAL DEMONSTRATION")
    print("  Anchor: Voice can propose. Evidence must prove. Only governance may mutate.")
    print("#" * 70)

    # ------------------------------------------------------------------
    # FLOW 1: Legitimate Procedural Recovery
    # ------------------------------------------------------------------
    print_step("FLOW 1: Legitimate Procedural Recovery (address.building_number: 14 -> 41)")
    gw1 = GovernanceGateway(APP_ID, SECRET)
    sess1 = gw1.start_session("sess_demo_legit")
    print(f"[STATE] Session Initiated: {gw1.get_state(sess1).value}")

    gw1.verify_identity(sess1, "IDV-4821AABBCCDDEEFF")
    print(f"[STATE] Identity Verified: {gw1.get_state(sess1).value}")

    ev1 = gw1.record_evidence(sess1, "address.building_number", "41", confirmation=True)
    print(f"[EVIDENCE] Recorded: {ev1} | Bound Value: '41'")

    tok1 = gw1.authorize_patch(sess1, ev1)
    print(f"[AUTH] Token Minted: {tok1.token_id[:16]}... (TTL: 60s)")

    res1 = gw1.commit_patch(tok1.token_id, sess1, "address.building_number", "41")
    print(f"[COMMIT] Result State: {res1}")
    print(f"[DATABASE] Updated Value: {gw1.get_value('address.building_number')}")
    print(f"[AUDIT] Blocks Recorded: {gw1.audit_export()['chain_metadata']['total_blocks']}")

    assert res1 == GovernanceState.RESUMED_IN_PROCESSING.value
    assert gw1.get_value("address.building_number") == "41"
    print(">>> FLOW 1 COMPLETE: SUCCESS")

    # ------------------------------------------------------------------
    # FLOW 2: Sovereign Decision Breach (applicant.eligibility_score)
    # ------------------------------------------------------------------
    print_step("FLOW 2: Sovereign Decision Breach Interception (H4-01)")
    gw2 = GovernanceGateway(APP_ID, SECRET)
    sess2 = gw2.start_session("sess_demo_sovereign")
    gw2.verify_identity(sess2, "IDV-DEMO-ATTACKER")

    ev2 = gw2.record_evidence(sess2, "applicant.eligibility_score", "100", confirmation=True)
    print(f"[EVIDENCE] Attempted Sovereign Mutation: applicant.eligibility_score = 100")

    try:
        gw2.authorize_patch(sess2, ev2)
        print("[FAIL] Sovereign mutation was authorized!")
        return 1
    except SovereignDecisionField as exc:
        print(f"[INTERCEPTED] Exception: {exc}")
        print(f"[STATE] Gateway State: {gw2.get_state(sess2).value}")
        last_event = gw2.audit_export()["blocks"][-1]["record"]["event_type"]
        print(f"[AUDIT] Escalation Event: {last_event}")
        assert gw2.get_state(sess2) == GovernanceState.ESCALATED_NO_PATCH
        assert last_event == "POLICY_REJECTION"
        print(">>> FLOW 2 COMPLETE: INTERCEPTED & ESCALATED")

    # ------------------------------------------------------------------
    # FLOW 3: Value-Binding Mismatch Attack (H4-09)
    # ------------------------------------------------------------------
    print_step("FLOW 3: Exact Value-Binding Mismatch Defense (H4-09: '41' vs '99')")
    gw3 = GovernanceGateway(APP_ID, SECRET)
    sess3 = gw3.start_session("sess_demo_mismatch")
    gw3.verify_identity(sess3, "IDV-DEMO-USER")

    ev3 = gw3.record_evidence(sess3, "address.building_number", "41", confirmation=True)
    tok3 = gw3.authorize_patch(sess3, ev3)
    print(f"[AUTH] Token Issued for Evidence Value: '41'")
    print(f"[ATTACK] Attempting Commit with Unauthorized Value: '99'")

    try:
        gw3.commit_patch(tok3.token_id, sess3, "address.building_number", "99")
        print("[FAIL] Mismatched value commit accepted!")
        return 1
    except EvidenceError as exc:
        print(f"[REJECTED] Mutation Blocked: {exc}")
        print(f"[DATABASE] Database Value Retained: {gw3.get_value('address.building_number')}")
        last_event = gw3.audit_export()["blocks"][-1]["record"]["event_type"]
        print(f"[AUDIT] Security Alert: {last_event}")
        assert gw3.get_value("address.building_number") == "14"
        assert last_event == "SECURITY_ALERT_VALUE_MISMATCH"
        print(">>> FLOW 3 COMPLETE: VALUE MISMATCH BLOCKED")

    print("\n" + "=" * 70)
    print("DEMO VERDICT: ALL 3 FLOWS COMPLIANT WITH GATE H5 SEAL")
    print("=" * 70 + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(run_demo())
