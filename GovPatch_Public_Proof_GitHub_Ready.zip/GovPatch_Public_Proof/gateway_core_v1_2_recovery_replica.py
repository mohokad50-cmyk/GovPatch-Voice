"""
GovPatch Voice v1.2
Governance Gateway Core
Evidence-Conditioned, Fail-Closed State Machine
"""
from __future__ import annotations
import hashlib, hmac, json, threading, time, uuid
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Optional, Tuple

class GovernanceState(str, Enum):
    STALLED="STALLED"; RECOVERY_INITIATED="RECOVERY_INITIATED"; IDENTITY_VERIFIED="IDENTITY_VERIFIED"
    PATCH_VALIDATED="PATCH_VALIDATED"; PATCH_AUTHORIZED="PATCH_AUTHORIZED"
    RESUMED_IN_PROCESSING="RESUMED_IN_PROCESSING"; ESCALATED_NO_PATCH="ESCALATED_NO_PATCH"

class GovernanceError(Exception): pass
class PolicyViolation(GovernanceError): pass
class InvalidTransition(GovernanceError): pass
class EvidenceError(GovernanceError): pass
class AuthorizationError(GovernanceError): pass
class ReplayAttack(GovernanceError): pass
class ConcurrentExecution(GovernanceError): pass
class SovereignDecisionField(GovernanceError): pass

@dataclass(frozen=True)
class Evidence:
    evidence_id:str; session_id:str; identity_id:str; field_key:str; value:str; confirmation:bool

@dataclass(frozen=True)
class AuthorizationToken:
    token_id:str; nonce:str; session_id:str; identity_id:str; field_key:str; evidence_id:str
    issued_at:float; expires_at:float; consumed:bool=False

class AuditChain:
    GENESIS="GENESIS_BLOCK_HASH_00000000000000000000000000000000"
    def __init__(self, secret:bytes):
        if not secret: raise ValueError("Audit secret must not be empty.")
        self._secret=bytes(secret); self._blocks=[]; self._lock=threading.RLock()
    @staticmethod
    def canonical_json(data:Dict[str,Any])->bytes:
        return json.dumps(data,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode("utf-8")
    def append(self,event_type:str,session_id:str,application_id:str,details:Dict[str,Any])->Dict[str,Any]:
        with self._lock:
            index=len(self._blocks)+1
            previous_hash=self.GENESIS if not self._blocks else self._blocks[-1]["hash"]
            record={"index":index,"event_type":event_type,"application_id":application_id,"session_id":session_id,
                    "details":details,"previous_hash":previous_hash}
            digest=hmac.new(self._secret,self.canonical_json(record),hashlib.sha256).hexdigest()
            block={"index":index,"record":record,"hash":digest}; self._blocks.append(block); return block
    def export(self)->Dict[str,Any]:
        with self._lock:
            latest=self.GENESIS if not self._blocks else self._blocks[-1]["hash"]
            return {"chain_metadata":{"total_blocks":len(self._blocks),"genesis_hash":self.GENESIS,"latest_block_hash":latest},
                    "blocks":list(self._blocks)}
    def verify_integrity(self)->Tuple[bool,int]:
        with self._lock:
            previous=self.GENESIS
            for block in self._blocks:
                record=block["record"]
                if record["previous_hash"]!=previous: return False, block["index"]
                expected=hmac.new(self._secret,self.canonical_json(record),hashlib.sha256).hexdigest()
                if not hmac.compare_digest(block["hash"],expected): return False, block["index"]
                previous=block["hash"]
            return True,len(self._blocks)

class GovernanceGateway:
    DEFAULT_TTL_SECONDS=60.0
    SOVEREIGN_DECISION_FIELDS=frozenset({"applicant.eligibility_score","eligibility.decision","benefit.approval","sanction.decision"})
    def __init__(self,application_id:str,audit_secret:bytes,ttl_seconds:float=DEFAULT_TTL_SECONDS):
        self.application_id=application_id; self.ttl_seconds=float(ttl_seconds)
        if self.ttl_seconds<=0: raise ValueError("TTL must be positive.")
        self.audit=AuditChain(audit_secret); self._states={}; self._identities={}; self._evidence={}; self._tokens={}
        self._database={"address.building_number":"14","applicant.eligibility_score":"50"}
        self._session_locks={}; self._global_lock=threading.RLock()
    def _lock_for_session(self,session_id):
        with self._global_lock:
            if session_id not in self._session_locks: self._session_locks[session_id]=threading.RLock()
            return self._session_locks[session_id]
    def _transition(self,session_id,expected,target):
        current=self._states.get(session_id,GovernanceState.STALLED)
        if current!=expected: raise InvalidTransition(f"{session_id}: expected {expected.value}, found {current.value}")
        self._states[session_id]=target
    def start_session(self,session_id=None):
        if session_id is None: session_id=f"sess_{uuid.uuid4().hex}"
        with self._lock_for_session(session_id):
            current=self._states.get(session_id,GovernanceState.STALLED)
            if current!=GovernanceState.STALLED: raise InvalidTransition("Session is already active.")
            self._states[session_id]=GovernanceState.RECOVERY_INITIATED
            self.audit.append("SESSION_INITIATED",session_id,self.application_id,{"state":GovernanceState.RECOVERY_INITIATED.value})
        return session_id
    def verify_identity(self,session_id,identity_id):
        with self._lock_for_session(session_id):
            self._transition(session_id,GovernanceState.RECOVERY_INITIATED,GovernanceState.IDENTITY_VERIFIED)
            self._identities[session_id]=identity_id
            self.audit.append("IDENTITY_VERIFIED",session_id,self.application_id,{"verification_id":identity_id})
    def record_evidence(self,session_id,field_key,value,confirmation=True):
        with self._lock_for_session(session_id):
            if self._states.get(session_id)!=GovernanceState.IDENTITY_VERIFIED: raise EvidenceError("Identity must be verified before evidence.")
            identity_id=self._identities.get(session_id)
            if identity_id is None: raise EvidenceError("No verified identity bound to session.")
            if not confirmation: raise EvidenceError("Explicit confirmation is required.")
            evidence_id=f"CONF-{uuid.uuid4().hex[:12].upper()}"
            evidence=Evidence(evidence_id,session_id,identity_id,field_key,str(value),True)
            self._evidence[evidence_id]=evidence; self._states[session_id]=GovernanceState.PATCH_VALIDATED
            self.audit.append("CONFIRMATION_EVIDENCE_RECORDED",session_id,self.application_id,
                              {"evidence_id":evidence_id,"field_key":field_key,"value":str(value)})
            return evidence_id
    def authorize_patch(self,session_id,evidence_id):
        with self._lock_for_session(session_id):
            if self._states.get(session_id)!=GovernanceState.PATCH_VALIDATED: raise AuthorizationError("Patch is not in PATCH_VALIDATED state.")
            evidence=self._evidence.get(evidence_id)
            if evidence is None: raise EvidenceError("Evidence does not exist.")
            if evidence.session_id!=session_id: raise AuthorizationError("Evidence/session binding mismatch.")
            if evidence.field_key in self.SOVEREIGN_DECISION_FIELDS:
                self._states[session_id]=GovernanceState.ESCALATED_NO_PATCH
                self.audit.append("POLICY_REJECTION",session_id,self.application_id,
                                  {"field_key":evidence.field_key,"reason":"SOVEREIGN_DECISION_FIELD","action":"ESCALATED_NO_PATCH"})
                raise SovereignDecisionField(f"Mutation forbidden for sovereign field: {evidence.field_key}")
            identity_id=self._identities.get(session_id)
            if identity_id!=evidence.identity_id: raise AuthorizationError("Identity/evidence binding mismatch.")
            now=time.monotonic()
            token=AuthorizationToken(f"tok_{uuid.uuid4().hex}",uuid.uuid4().hex,session_id,identity_id,
                                     evidence.field_key,evidence_id,now,now+self.ttl_seconds)
            self._tokens[token.token_id]=token; self._states[session_id]=GovernanceState.PATCH_AUTHORIZED
            self.audit.append("PATCH_AUTHORIZED",session_id,self.application_id,
                              {"field_key":evidence.field_key,"evidence_id":evidence_id,"nonce":token.nonce,"ttl_sec":self.ttl_seconds})
            return token
    def commit_patch(self,token_id,session_id,field_key,new_value):
        with self._lock_for_session(session_id):
            token=self._tokens.get(token_id)
            if token is None: raise AuthorizationError("Unknown authorization token.")
            if token.session_id!=session_id:
                self.audit.append("SECURITY_ALERT_REPLAY_ATTACK",session_id,self.application_id,
                                  {"token_id":token_id,"reason":"SESSION_BINDING_MISMATCH"})
                raise ReplayAttack("Authorization token belongs to another session.")
            if token.field_key!=field_key: raise AuthorizationError("Authorization token is bound to another field.")
            if time.monotonic()>token.expires_at: raise AuthorizationError("Authorization token expired.")
            current_token=self._tokens[token_id]
            if current_token.consumed:
                self.audit.append("SECURITY_ALERT_REPLAY_ATTACK",session_id,self.application_id,
                                  {"token_id":token_id,"reason":"TOKEN_ALREADY_CONSUMED"})
                raise ReplayAttack("Authorization token already consumed.")
            if self._states.get(session_id)!=GovernanceState.PATCH_AUTHORIZED: raise AuthorizationError("Session is not authorized for commit.")
            if field_key in self.SOVEREIGN_DECISION_FIELDS:
                self._states[session_id]=GovernanceState.ESCALATED_NO_PATCH
                raise SovereignDecisionField("Sovereign decision mutation blocked.")
            evidence=self._evidence.get(token.evidence_id)
            if evidence is None: raise EvidenceError("Token-bound evidence does not exist.")
            if evidence.session_id!=session_id: raise EvidenceError("Evidence/session binding mismatch at commit.")
            if evidence.identity_id!=token.identity_id: raise EvidenceError("Evidence/identity binding mismatch at commit.")
            if evidence.field_key!=field_key or evidence.field_key!=token.field_key:
                raise EvidenceError("Evidence/field binding mismatch at commit.")
            if str(new_value)!=str(evidence.value):
                self.audit.append("SECURITY_ALERT_VALUE_MISMATCH",session_id,self.application_id,
                                  {"token_id":token_id,"evidence_id":token.evidence_id,
                                   "expected_value":str(evidence.value),"attempted_value":str(new_value)})
                raise EvidenceError(f"Value mismatch: attempted {str(new_value)!r} does not match evidence {str(evidence.value)!r}.")
            self._tokens[token_id]=AuthorizationToken(token.token_id,token.nonce,token.session_id,token.identity_id,
                                                      token.field_key,token.evidence_id,token.issued_at,token.expires_at,True)
            old_value=self._database.get(field_key); self._database[field_key]=str(new_value)
            self._states[session_id]=GovernanceState.RESUMED_IN_PROCESSING
            self.audit.append("PATCH_EXECUTED",session_id,self.application_id,
                              {"field":field_key,"old_value":old_value,"new_value":str(new_value),
                               "identity_id":token.identity_id,"evidence_id":token.evidence_id})
            return GovernanceState.RESUMED_IN_PROCESSING.value
    def get_state(self,session_id): return self._states.get(session_id,GovernanceState.STALLED)
    def get_value(self,field_key): return self._database.get(field_key)
    def audit_export(self): return self.audit.export()
    def verify_integrity(self): return self.audit.verify_integrity()
